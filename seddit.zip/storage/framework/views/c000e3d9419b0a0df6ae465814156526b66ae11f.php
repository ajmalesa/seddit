

<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Hello</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\seddit\seddit\resources\views/Home.blade.php ENDPATH**/ ?>