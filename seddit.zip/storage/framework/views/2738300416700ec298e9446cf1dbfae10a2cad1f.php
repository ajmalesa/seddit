

<?php $__env->startSection('title', 'Seddit'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="display-4">seddit<small class="text-muted version"> 0.1.0</small></h1>
    
    <select class="form-control w-25 mb-2" onChange="window.location.href=this.value" id="sort_order" name="sort">
        <li><option value="/">new</option></li>
        <li><option <?php if(Request::is('*top')): ?> <?php echo e("selected"); ?> <?php endif; ?> value="top">top</option></li>
    </select>

    <ol>
        
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a class="post_links" href="<?php echo e($post->url); ?>" target="_blank">
                    <strong><?php echo e($post->content); ?></strong>
                </a> 
                - <?php echo e($post->author); ?>

                - (<span class="vote_count" id="<?php echo e($post->id); ?>"><?php echo e($post->votes); ?></span>)
                - <a id="<?php echo e($post->id); ?>" class="arrows upvote_arrows">↑</a> 
                <a id="<?php echo e($post->id); ?>" class="arrows">↓</a>
            </li> 
            
            <a href="#"> comments</a>

            
            <span title = "<?php echo e($post->created_at->format('m/d/y h:ma')); ?>">
                <?php echo e($post->created_at->diffForHumans()); ?>

            </span>            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

    <a class="btn btn-outline-dark" href="create"><span class="submit">submit new post</span></a>

    <script type="text/javascript">
        // Required token for cross-site request forgery protection
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Run this code when arrow is clicked
        $(document).on('click', '.arrows', function() {

            // Initialize point that will be added to 0, which will be changed 
            // depending on which arrow was selected
            var point = 0;

            // If the arrow that was clicked has a class of upvote_arrows, set
            // point to a positive 1, otherwise set to negative 1 and change 
            // classes to update colors to match vote
            if($(this).hasClass('upvote_arrows') && !$(this).hasClass('voted_up')) {
                point += 1;
                $(this).addClass('voted_up');
            } else if(!$(this).hasClass('upvote_arrows') && !$(this).hasClass('voted_down')) {
                point -= 1;
                $(this).addClass('voted_down');
            } else if ($(this).hasClass('upvote_arrows') && $(this).hasClass('voted_up')) { 
                // Remove upvote class when button if upvote button is clicked again
                // and remove class to change color back to default
                point -= 1;
                $(this).removeClass('voted_up');
            } else if (!$(this).hasClass('upvote_arrows') && $(this).hasClass('voted_down')) { 
                // Remove downvote class when button if downvote button is clicked again
                // and remove class to change color back to default
                point += 1;
                $(this).removeClass('voted_down');
            } 

            // Set the id to that will be sent in ajax post to the id from the 
            // post that the arrows was clicked on
            var id = this.id;

            // Update point count for post being updated in real time,
            // for just the front end for real time user feedback on votes
            $("#" + id)[0].innerHTML = parseInt($("#" + id)[0].innerHTML) + point;

            // Send AJAX post to index page '/' with the id of post to update
            // and point amount to increment or decrement by
            $.ajax({
                type:'POST',
                url:'/',
                data:{id:id, point:point}      
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\seddit\seddit\resources\views/pages/home.blade.php ENDPATH**/ ?>