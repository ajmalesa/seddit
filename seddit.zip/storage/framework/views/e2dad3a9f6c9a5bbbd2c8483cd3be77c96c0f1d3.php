

<?php $__env->startSection('title', 'Seddit - Create Post'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="display-4">create</h1>

    <form autocomplete="off" id="create_form" action="/create" method="post">
        <?php echo csrf_field(); ?>
        <input placeholder="content" class="form-control w-50" type="text" name="content"><br>
        <input placeholder="author" class="form-control w-50" type="text" name="author"><br>
        <input placeholder="url" class="form-control w-50" id="url" type="text" name="url"><br>   
        <button class="btn btn-outline-success" type="submit">submit</button>
        <button class="btn btn-outline-danger" type="button" value="cancel" onclick="window.location.href='../'">cancel</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\seddit\seddit\resources\views/pages/create.blade.php ENDPATH**/ ?>