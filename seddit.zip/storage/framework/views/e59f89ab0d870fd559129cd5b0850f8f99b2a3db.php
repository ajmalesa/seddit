

<?php $__env->startSection('title', 'Seddit'); ?>

<?php $__env->startSection('content'); ?>

    <h1>seddit</h1>

    <ol>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e($post->url); ?>">
                <strong><?php echo e($post->content); ?></strong>
            </a> 
            - <?php echo e($post->author); ?>

        </li> 
        
        <span
            title="<?php echo e($post->created_at->format('m/d/y h:ma')); ?>">
            <?php echo e($post->created_at->diffForHumans()); ?>

        </span>
                    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\seddit\seddit\resources\views/home.blade.php ENDPATH**/ ?>