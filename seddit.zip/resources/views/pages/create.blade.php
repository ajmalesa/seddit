@extends('layouts/master')

@section('title', 'Seddit - Create Post')

@section('content')

    <h1 class="display-4">create</h1>

    <form autocomplete="off" id="create_form" action="/create" method="post">
        @csrf
        <input placeholder="content" class="form-control w-50" type="text" name="content"><br>
        <input placeholder="author" class="form-control w-50" type="text" name="author"><br>
        <input placeholder="url" class="form-control w-50" id="url" type="text" name="url"><br>   
        <button class="btn btn-outline-success" type="submit">submit</button>
        <button class="btn btn-outline-danger" type="button" value="cancel" onclick="window.location.href='../'">cancel</button>
    </form>

@endsection